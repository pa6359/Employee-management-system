# Employee-Management-System
An Employee Management System use to store information of every Employee in Company.
